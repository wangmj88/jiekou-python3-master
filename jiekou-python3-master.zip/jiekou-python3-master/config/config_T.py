""" 
@author: lileilei
@file: config_T.py
@time: 2018/4/12 14:17 
"""
Dingtalk_access_token="" #钉钉配置
TestPlanUrl='http://www.tuling123.com'  #基础url
Config_Try_Num=3#失败重试